import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { ValidationService } from '../../services/validation.service';
import {ApiService} from '../../services/api.service';
import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2/dist/sweetalert2.js'



@Component({
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {

  constructor(private fb: FormBuilder, private api:ApiService,private router: Router, private loading: NgxSpinnerService) { }

  ngOnInit() {
  }

  forgetpwdForm = this.fb.group({
    email: ['', [Validators.required,ValidationService.emailValidator]],
  });


  onSubmit()
  {
    this.api.forgetpwd(this.forgetpwdForm.value).subscribe(res =>{
      if(res.status){
        Swal.fire('Success..', 'Password sent to your mail check it once.', 'success'); 
        this.forgetpwdForm.patchValue({email:''});
      }else{
        Swal.fire('Oops...', 'Something went wrong!', 'error');
        this.forgetpwdForm.patchValue({email:''});
      }
    });

  }
}
