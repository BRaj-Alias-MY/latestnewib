import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../app.service';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-videos',
  templateUrl: './videos.component.html',
  styleUrls: ['./videos.component.css']
})
export class VideosComponent implements OnInit {
  email = localStorage.getItem('email');
  currentInterviewId = localStorage.getItem('currentInterview');
  videosList = [];
  videoURLs: any;
  constructor(private service: AppService, private router: Router) { }

  ngOnInit() {
    this.getVideos();
    $(document).ready(function () {
      // alert('test');

    });
  }

  getVideos() {
    //alert(this.email);
    this.service.getVideos(this.email, parseInt(this.currentInterviewId)).subscribe(resp => { console.log('hi'); console.log(resp); this.videosList = resp; }, err => console.log(err));

  }
  gotoHome() {
    this.router.navigate(['/examboard/entrypage']);
  }


}
