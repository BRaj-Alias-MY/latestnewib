import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { MatDialogRef } from "@angular/material";
import { Userprofile2Component } from '../userprofile2/userprofile2.component';
import { HttpClient } from "@angular/common/http";
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { Education } from "../education/education";

declare var $: any;
@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css']
})
export class EducationComponent implements OnInit {
  myDateValue: Date;
  myDateValue2: Date;
  educationForm: FormGroup;
  result: any;
  successmsg: any;
  education: Education;
  EDU_URL = "http://localhost:3000/api/userprofile/saveedu2";
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private http: HttpClient,
    public dialogRef: MatDialogRef<Userprofile2Component>) {
    this.education = new Education();
  }
  userId = localStorage.getItem('userId');
  ngOnInit() {
    this.myDateValue = new Date();
    this.myDateValue2 = new Date();
    this.userId = localStorage.getItem('userId');
    //alert(this.userId);
    this.educationForm = this.fb.group({
      education: [''],
      userId: [this.userId],
      userProfileId: [this.userId],
      university: [''],
      courseFrom: [''],
      courseTo: [''],
      specilization: [''],
      grade: [''],
    })
  }
  close() {
    // alert('test');
    this.dialogRef.close("Thanks for using me!");
    window.location.reload();


  }
  success() {
    this.router.navigate(['/examboard2/testsetup2']);
    this.dialogRef.close("Thanks for using me!");
  }
  onDateChange(newDate: Date) {
    console.log(newDate);
  }
  onEducation() {

    this.education = this.educationForm.value;
    this.http.post<any>(this.EDU_URL, this.education).subscribe(resp => { this.successmsg = 'Added Successfully'; console.log(resp); }, err => console.log(err));
  }


}
