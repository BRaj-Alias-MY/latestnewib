import { Component, OnInit, Input  } from '@angular/core';

@Component({
  selector: 'app-view-rating',
  templateUrl: './view-rating.component.html',
  styleUrls: ['./view-rating.component.css']
})
export class ViewRatingComponent implements OnInit {
  disprat:any
  @Input() rating:any;
  @Input() forval:number;
  constructor() { }

  ngOnInit() {
    this.disprat = this.ratingDisplay(this.rating,this.forval);
  }

  ratingDisplay(r,s){
    let disp = '';
    let a = Math.floor(r);
    for(let i=0;i<a;i++){
      disp+='<i class="fas fa-star"></i>';
    }
    if((r-a)>0){
      disp+='<i class="fas fa-star-half-alt"></i>';
      a++;
    }
    for(let i=0;i<s-a;i++){
      disp+='<i class="far fa-star"></i>';
    }
    return disp;
  }
}
