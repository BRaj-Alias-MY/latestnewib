import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ApiService} from '../../services/api.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ValidationService } from '../../services/validation.service';
import Swal from 'sweetalert2/dist/sweetalert2.js'



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls : ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: usr;
  userdata :any;
  constructor(private fb: FormBuilder, private api:ApiService,private router: Router, private loading: NgxSpinnerService) {

      }

  ngOnInit() {
    this.user = {
      email : '',
      password : ''
    };
    if(this.api.getToken()){
      if(this.api.getUser().roleId==5){
        localStorage.setItem('email',this.api.getUser().email);
        localStorage.setItem('userId',this.api.getUser().id);
        this.router.navigate(['/examboard/entrypage']);
      }else{
        this.router.navigate(['/main/dashboard']);
      }
    }
  }

  registrationForm = this.fb.group({
		id:[],
    fname: ['',ValidationService.alphaValidator],
    mname: [''],
    lname: ['',ValidationService.alphaValidator],
    email: ['',ValidationService.emailValidator],
    phone: ['',ValidationService.numericValidator],
    gender: ['',ValidationService.alphaValidator],
    password: ['']
    
    });

  login() {
    //alert('testing');
    //this.router.navigate(['/main/dashboard']);
    if (this.user.email && this.user.password) {
      //this.loading.show();
      this.api.login(this.user).subscribe(res => {
        this.loading.hide();
        if (res.token) {
          this.api.storageuserdata(res.token, res.user);
          this.user = {
            email : '',
            password : ''
          };
          if(res.user.roleId==5){
            localStorage.setItem('email',res.email);
            localStorage.setItem('userId',res.id);
            this.router.navigate(['/examboard/entrypage']);
          }else{
            this.router.navigate(['/main/dashboard']);
          }
        } else {
          Swal.fire('Login Fail.', 'Your email or password is incorrect.', 'error');
          this.user.password = '';
        }
      }); 
    } else {
      Swal.fire('Oops..', 'Please fill all fields.', 'error');
    }
  }

  onSubmit(){
    this.api.createuser(this.registrationForm.value).subscribe((res) => {
      if (res.status) {
        Swal.fire('Success!', 'You have Sucessfully Registered. Please Login','success');        
        this.registrationForm.patchValue({fname: '',mname:  '',lname:  '',password: '',email: '',
         phone: '', gender:''});

      } else {
        Swal.fire('Oops..', 'Please fill all mandatory fields.', 'error');
      }
    });
  }
}
interface usr {
  email: string ,
  password: string
}
