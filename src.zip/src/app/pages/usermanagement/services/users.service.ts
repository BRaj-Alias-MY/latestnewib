import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../../services/api.service';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  constructor(private main_api: ApiService, private http: HttpClient) {}

  // userprofile_update(data) {
  //   return this.http.post<any>(this.main_api.get_base() + 'organization', data);
  // }
  add_userprofile(data) {
    return this.http.post<any>(this.main_api.get_base() + 'userprofile', data);
  }

  get_roles() {
    return this.http.get<any>(this.main_api.get_base() + 'user/roles');
  }

   getuserList(): any {
    return this.http.get<any>(this.main_api.get_base() + 'dashboard/user');
  }
  
  get_organization() {
    return this.http.get<any>(this.main_api.get_base() + 'organization/list');
  }

  get_domain() {
    return this.http.get<any>(this.main_api.get_base() + 'domain/list');
  }

  get_subdomain(id) {
    return this.http.get<any>(this.main_api.get_base() + 'domain/list/' + id);
  }

  get_user_groups() {
    return this.http.get<any>(this.main_api.get_base() + 'usergroup/list');
  }

  getusers(){
    return this.http.get<any>(this.main_api.get_base() + 'user/getusers');
  }

  save_userdomain(data) {
    return this.http.post<any>(
      this.main_api.get_base() + 'user/create-user',
      data
    );
  }
  save_userprofile(data) {
    return this.http.post<any>(
      this.main_api.get_base() + 'userprofile/profilesave',
      data
    );
  }
  save_userprofile_edu(data) {
    return this.http.post<any>(
      this.main_api.get_base() + 'userprofile/saveedu',
      data
    );
  }
  save_userprofile_exp(data) {
    return this.http.post<any>(
      this.main_api.get_base() + 'userprofile/saveexp',
      data
    );
  }
}
