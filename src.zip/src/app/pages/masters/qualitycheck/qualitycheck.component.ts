import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import {MastersService} from '../services/masters.service';
import { GridOptions } from 'ag-grid-community';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-qualitycheck',
  templateUrl: './qualitycheck.component.html',
  styleUrls: ['./qualitycheck.component.css']
})
export class QualitycheckComponent implements OnInit {

  access;
  quality_check;
  viewSt:boolean;
  qca;
  constructor(private fb: FormBuilder, private route: Router, private api: MastersService) {}

  ngOnInit() {
    this.viewSt = false;
    this.qca = {};
    this.access = {
      addAccess: 0,
      editAccess: 0,
      deleteAccess: 0,
      gridAccess: 0
    };
    this.quality_check=[];
    this.grid();
  }


  grid() {
     console.log(this.api.get_qc_data);
    this.api.get_qc_data().subscribe(data => {
      this.quality_check=data.data
      //console.log(this.quality_check);
    });
  }
  accept(qc,status){
    this.api.quality_check({id:qc,status:status}).subscribe(res => {
     if(res.status){
      Swal.fire('Success..',  'success'); 
      this.closeview();
      this.grid();
     }else{
      Swal.fire('Oops...', 'error');

     }

    });
  }

  view_data(qc){
    this.viewSt = true;
    this.qca = qc;
    this.api.get_qc_data_remarks(qc.id).subscribe(resu=>{
      if(resu.status)
        this.qca.remarks = resu.data;
      else
        this.qca.remarks = []

        console.log(this.qca); 
    })
  }

  closeview(){
    this.viewSt = false;
    this.qca = {};
  }
}